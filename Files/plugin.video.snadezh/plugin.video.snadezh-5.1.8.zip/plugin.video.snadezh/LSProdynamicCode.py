#$pyFunction
import re,requests
def GetLSProData(page_data,Cookie_Jar,m):
  source=requests.get(re.findall('mpegURL","url":"(h.*m3u8.*?)"',page_data)[0].replace('\\','')+'&redirect=0',headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0','Referer':'http://www.dailymotion.com/embed/video/x3b68jn','X-Requested-With':'XMLHttpRequest','Accept':'*/*'}).text
  return re.findall('(.*live-[3,4].*)#',source)[0] # 3 for 720p & 4 for 1080p
