#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
  import json
  tvs = []
  tpages = json.loads(page_data)['MatchList']
  for tv in tpages:
    if tv['live']:
      title = tv['title']
      url = tv['url']
      tvs.append((title,url))
  return tvs
