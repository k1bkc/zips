#$pyFunction
import re,requests
def GetLSProData(page_data, Cookie_Jar,m):#streamwatcher
  headers={'user-aget':'Mozilla/5.0','origin':'https://www.telewebion.com','referer':'https://www.telewebion.com/live/tv3','accept':'*/*'}
  url='https://api.telewebion.com/v3/channels/tv3/details?device=desktop&logo_version=4&thumb_size=240&dvr=1&'
  source=requests.get(url,headers=headers).content
  return re.findall('"link":"([^"]+)',source)[0]+'|user-agent=ipad&origin=https://www.telewebion.com&referer=https://www.telewebion.com/live/tv3'
